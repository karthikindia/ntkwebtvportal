# This Software must be used for Good, never Evil. It is expressly forbidden to use to build porn sites, violence, racism or anything else that affects human integrity or denigrates the image of anyone.This code is to support for the development of my tamil community naam tamilar political party web tv portal

# Now you can read the rest...


### Are you having a hard time to configure or install NTK Web TV Portal or any of its resources? fell free to ask us for help then contact email : me@karthik.sg

# NTK Web TV Portal
NTK Web TV Portal is an video-sharing website, It is an open source solution that is freely available to everyone. With NTK Web TV Portal you can create your own video sharing site, NTK Web TV Portal will help you import and encode videos from other sites like Youtube, Vimeo, etc. and you can share directly on your website. In addition, you can use Facebook or Google login to register users on your site. The service was created in march 2017.

<div align="center">
<a href="http://ntkfm.cobrasoftwares.in/tv/" target="_blank">View Demo</a>
</div>


# Server Requirements

In order for you to be able to run NTK Web TV Portal, there are certain tools that need to be installed on your server. Don't worry, they are all FREE. To have a look at complete list of required tools, click the link below.

- PHP 5.3+
- MySQL 5.0+
- Apache web server 2.x (with mod_rewrite enabled)

# Version 1.2
In this version registered users need the NTK Web TV Portal administrator to grant them permission to transmit streams

# Version 1.1
In this version you can embed Youtube and Vimeo Links

# What is new on this version 1.0?
Since version 4.x+ we separate the streamer website from the encoder website, so that we can distribute the application on different servers.
- The Streamer site, is the main front end and has as main function to attend the visitors of the site, through a layout based on the youtube experience, you can host the streamer site in any common internet host can host it (Windows or Linux).

Forked from youtubephpencoder, thanks to Daniel

Please contact me@karthik.sg for any more info


